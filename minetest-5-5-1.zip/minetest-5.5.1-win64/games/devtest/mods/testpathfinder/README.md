# Pathfinder Tester

Usage:

Use the Pathfinder Tester tool (`testpathfinder:testpathfinder`).
Here's how it works:

* Place on node: Set destination position
* Punch: Find path
* Sneak+punch: Select pathfinding algorithm

Information will be shown in chat. If a path was found, all waypoints
will be shown for a few seconds.

See `init.lua` for config variables.
